import { action, awaitSignal, defineWorkflow, map } from "@intx/workflow";
import {
  deterministicToolStep,
  agentStep,
  canonicalizeStepToolName,
  LLM_WRITER_MODEL,
} from "@workbench/agents";
import { buildAnalyzeSystemPrompt, buildCurateSystemPrompt } from "./prompts";

// Curate emits up to 12 opportunities, each carrying a full markdown brief in
// `content` — long-form output. On the fast default model's small/unset
// maxTokens it truncated mid-JSON (the reply came back as an unterminated
// string and the panel could parse no opportunities). Run it on the heavier
// writer model with an explicit ceiling, matching last30days' curate step.
const CURATE_MAX_TOKENS = 16384;

// -------------------------------------------------------------------------
// Workflow metadata
// -------------------------------------------------------------------------

export const label = "Reddit Opportunity Scanner";
export const description =
  "Scan a website, review keyword and subreddit recommendations, then rank Reddit opportunities for follow-up.";
export const kind = "reddit-opportunity-scanner";

// Re-export the user-facing display flow so it travels with the workflow package
// for the server catalog classifier; the client panel imports it from the same
// browser-safe module.
export { DISPLAY_STEPS } from "./display-steps";

// -------------------------------------------------------------------------
// Workflow definition — guided Reddit research flow (CL-2513)
//
// Reddit API calls are deterministic and inspectable. The LLM is reserved for
// genuine judgment: first planning the strategy (analyze), then curating the
// fetched Reddit evidence into opportunities (curate). This mirrors the
// Last30Days collect → curate shape while keeping a human gate before scanning
// (review) and before saving (selection).
// -------------------------------------------------------------------------

// The collect step's per-row tool-arg mapping — exported so the fidelity
// integration test asserts against the REAL field names (a typo here fails the
// map trap the test guards, not a hand-rolled copy).
export const COLLECT_ARG_MAP = {
  subreddit: { from: "subreddit" },
  query: { from: "query" },
  sort: { from: "sort" },
  timeframe: { from: "timeframe" },
  limit: { from: "limit" },
} as const;

// The persist step's per-opportunity tool-arg mapping — exported for the same
// reason: the fidelity test reads `title`/`content` from here, not a copy.
export const PERSIST_ARG_MAP = {
  title: { from: "title" },
  kind: { literal: "reddit-opportunity-scan" },
  content: { from: "content" },
} as const;

// `nonFatal` is retired here (CL-4464): the tolerance moves into the wrapper
// tool itself (`collect-tool.ts`), which calls the real
// `reddit_subreddit_search` in-process and returns a completed non-error
// envelope on a failed search instead of throwing. `collect` stays a
// `deterministicToolStep` map inner step — not a migration gap, a
// structural one: `map`'s `step` is typed `StepPrimitive` only
// (interchange/packages/workflow/src/definition/primitives.ts), so a native
// `action` cannot host it regardless of nonFatal.
const collectStep = deterministicToolStep({
  id: "reddit-opp-collect-search",
  title: "Search each subreddit",
  tool: "reddit_opportunity_scanner_collect_search",
  // map passes each approved search as trigger.payload.
  input: { from: "trigger.payload" },
  argMap: COLLECT_ARG_MAP,
});

const persistStep = deterministicToolStep({
  id: "reddit-opp-persist-item",
  title: "Save each opportunity",
  tool: "artifact_create",
  // map passes each selected opportunity as trigger.payload.
  input: { from: "trigger.payload" },
  argMap: PERSIST_ARG_MAP,
});

// Native `action` handler ref for the one step this migration can move:
// `scrape`. `collect` and `persist` stay on `deterministicToolStep` — not by
// choice but because `map`'s `step` is typed `StepPrimitive` only
// (interchange/packages/workflow/src/definition/primitives.ts) and its
// runtime (`runMap` in runtime/run.ts) invokes exclusively via `invokeStep`;
// there is no code path to dispatch an `ActionPrimitive` per map iteration.
// CL-4464 considered folding the per-search iteration into one looping
// action (as `granola_spawn_call_runs` does), which would sidestep this
// typing gap entirely — but `steps.collect.output` today is a bare array
// (map's `runMap` return value, one entry per approved search) that
// `curate`'s system prompt documents verbatim ("collect.output: one Reddit
// result list per approved search"), and a folded single-tool-call action
// would instead expose `steps.collect.output` as one wrapped `ToolResult`
// (`{ callId, content, isError }`) around that array — a real shape change
// to what the curate step's context sees, plus coarser per-search
// checkpointing (map's `runStep` per iteration already commits a
// separately-resumable `StepStarted`/`StepCompleted` pair per search). That
// is a material behavior change, not just a mechanical migration, so it was
// not made here; `collect` keeps its map + deterministicToolStep shape and
// only the `nonFatal` tag retires (CL-4464), moved into `collect-tool.ts`.
export const FIRECRAWL_SCRAPE_HANDLER = canonicalizeStepToolName(
  "reddit-opp-scrape",
  "firecrawl_scrape",
);

export const workflow = defineWorkflow({
  id: kind,
  trigger: { type: "manual" },
  steps: {
    // 1. Human supplies the website URL + optional brand / geography / ICP hints.
    intake: awaitSignal({ name: "intake" }),

    // 2. Scrape the site. Native action: `firecrawl_scrape`'s schema
    //    declares `url` verbatim, so intake's own `url` field (renamed from
    //    the pre-migration `inputUrl` to match the tool arg — native
    //    selectors cannot rename a key) passes through unchanged.
    scrape: action({
      handler: FIRECRAWL_SCRAPE_HANDLER,
      input: { from: "steps.intake.output" },
      effect: { requires: [FIRECRAWL_SCRAPE_HANDLER] },
      after: ["intake"],
    }),

    // 3. Infer business profile + keyword/subreddit recommendations.
    //    Pure reasoning over the scraped content + intake hints — no tool.
    analyze: agentStep({
      id: "reddit-opp-analyze",
      title: "Recommend subreddits & keywords",
      systemPrompt: buildAnalyzeSystemPrompt(),
      input: {
        merge: [
          { from: "steps.scrape.output" },
          { from: "steps.intake.output" },
        ],
      },
      after: ["scrape"],
    }),

    // 4. Human accepts / edits the strategy. The panel sends concrete searches
    //    ({subreddit, query, sort, timeframe, limit}) for deterministic collection.
    review: awaitSignal({ name: "recommendation-review", after: ["analyze"] }),

    // 5. Deterministically fetch Reddit evidence for each approved search.
    collect: map({
      over: { from: "steps.review.output.searches" },
      step: collectStep,
      after: ["review"],
    }),

    // 6. Judge the collected Reddit evidence and produce ranked opportunity briefs.
    //    Narrow the input to just the approved plan + collected results — the
    //    full scrape markdown and analyze blob are dead weight in the curate
    //    context (token cost + distraction), and the prompt only reads these two.
    curate: agentStep({
      id: "reddit-opp-curate",
      title: "Rank the opportunities",
      systemPrompt: buildCurateSystemPrompt(),
      input: { project: { from: "steps" }, fields: ["review", "collect"] },
      model: LLM_WRITER_MODEL,
      maxTokens: CURATE_MAX_TOKENS,
      after: ["collect"],
    }),

    // 7. Human reviews ranked opportunities and selects which to keep.
    //    Payload carries the full selected opportunity objects so `persist`
    //    can map over them directly.
    selection: awaitSignal({
      name: "opportunity-selection",
      after: ["curate"],
    }),

    // 8. One artifact per selected opportunity, saved deterministically.
    persist: map({
      over: { from: "steps.selection.output.selected" },
      step: persistStep,
      after: ["selection"],
    }),
  },
});
