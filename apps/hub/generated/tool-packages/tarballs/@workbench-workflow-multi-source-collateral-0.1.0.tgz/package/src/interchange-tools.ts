// Native `interchange.tools` entry for @workbench/workflow-multi-source-collateral
// Wraps `linear_list_issues` so the source-listing step can
// tolerate an unconfigured or failing Linear provider in-process, instead of
// the retired sidecar-wide `nonFatal` tag (no equivalent on native `action`).
// Declares the same tool-credential env key the wrapped package itself
// declares, so the hub still resolves + injects the `linear` credential when
// one is configured.

import { createToolRunner, defineTool } from "@intx/agent";
import {
  createMultiSourceCollateralListIssuesTools,
  LIST_ISSUES_TOOL_REQUIRES,
} from "./list-issues-tool";
import {
  createMultiSourceCollateralFetchTools,
  FETCH_TOOLS_REQUIRES,
} from "./fetch-tools";
import {
  createMultiSourceCollateralPersistTools,
  PERSIST_TOOLS_REQUIRES,
} from "./persist-tools";

export const multiSourceCollateralListIssues = defineTool({
  id: "@workbench/workflow-multi-source-collateral/list-issues",
  requires: LIST_ISSUES_TOOL_REQUIRES,
  factory: (env) =>
    createToolRunner(createMultiSourceCollateralListIssuesTools(env)),
});

export const multiSourceCollateralFetch = defineTool({
  id: "@workbench/workflow-multi-source-collateral/fetch",
  requires: FETCH_TOOLS_REQUIRES,
  factory: (env) =>
    createToolRunner(createMultiSourceCollateralFetchTools(env)),
});

export const multiSourceCollateralPersist = defineTool({
  id: "@workbench/workflow-multi-source-collateral/persist",
  requires: PERSIST_TOOLS_REQUIRES,
  factory: (env) =>
    createToolRunner(createMultiSourceCollateralPersistTools(env)),
});
