import type { AgentTool } from "@intx/agent";
import type { ToolDefinition } from "@intx/types/runtime";
import { TEMPLATE_DEFINITIONS, createTemplateTools } from "./templates";
import { THEME_DEFINITIONS, createThemeTools } from "./themes";
import {
  PRESENTATION_DEFINITIONS,
  createPresentationTools,
} from "./presentations";
import type { GammaToolsConfig } from "./shared";

export type { GammaFetch, GammaToolsConfig } from "./shared";
export { GAMMA_DEFAULT_BASE_URL } from "./shared";
export { type GammaTemplate } from "./templates";
export {
  GAMMA_LIST_TEMPLATES_DEFINITION,
  GAMMA_CREATE_FROM_TEMPLATE_DEFINITION,
  TEMPLATE_DEFINITIONS,
  createTemplateTools,
  generateFromTemplate,
} from "./templates";
export {
  GAMMA_LIST_THEMES_DEFINITION,
  THEME_DEFINITIONS,
  createThemeTools,
} from "./themes";
export {
  GAMMA_DUPLICATE_PRESENTATION_DEFINITION,
  PRESENTATION_DEFINITIONS,
  createPresentationTools,
} from "./presentations";

export const GAMMA_DEFINITIONS: ToolDefinition[] = [
  ...TEMPLATE_DEFINITIONS,
  ...THEME_DEFINITIONS,
  ...PRESENTATION_DEFINITIONS,
];

export function createGammaTools(config: GammaToolsConfig): AgentTool[] {
  return [
    ...createTemplateTools(config),
    ...createThemeTools(config),
    ...createPresentationTools(config),
  ];
}

function createGammaToolByName(
  config: GammaToolsConfig,
  name: string,
): AgentTool[] {
  return createGammaTools(config).filter(
    (tool) => tool.definition.name === name,
  );
}

// gamma_list_templates reads tenant-owned templates from the hub DB, so it is
// excluded from GAMMA_HUB_TOOLS (credential-backed Gamma API tools) and is
// instead its own hub-backed factory (`gammaTemplates` in interchange-tools.ts),
// executed hub-side by apps/hub/src/tools/gamma-templates.ts.
const GAMMA_HUB_DEFINITIONS = GAMMA_DEFINITIONS.filter(
  (d) => d.name !== "gamma_list_templates",
);

// GammaToolsConfig uses `baseUrl`; the hub registry passes `baseURL` (capital URL)
// to match the convention of other tool registries. The bridge below aligns them.
const GAMMA_WRITE_TOOLS = new Set([
  "gamma_create_from_template",
  "gamma_duplicate_presentation",
]);

export const GAMMA_HUB_TOOLS = Object.fromEntries(
  GAMMA_HUB_DEFINITIONS.map((definition) => [
    definition.name,
    {
      sideEffect: (GAMMA_WRITE_TOOLS.has(definition.name)
        ? "write"
        : "read") as "read" | "write",
      definition,
      providerName: "gamma" as const,
      createTools: (config: {
        apiKey: string;
        baseURL?: string;
        fetcher?: GammaToolsConfig["fetcher"];
      }) =>
        createGammaToolByName(
          {
            apiKey: config.apiKey,
            ...(config.baseURL ? { baseUrl: config.baseURL } : {}),
            ...(config.fetcher ? { fetcher: config.fetcher } : {}),
          },
          definition.name,
        ),
    },
  ]),
);
